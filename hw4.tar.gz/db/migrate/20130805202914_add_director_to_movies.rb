class AddDirectorToMovies < ActiveRecord::Migration
  def change
  end
end
