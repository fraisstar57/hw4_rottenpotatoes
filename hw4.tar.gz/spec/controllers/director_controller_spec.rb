require 'spec_helper'

describe DirectorController do

  describe "GET 'similarMovies'" do
    it "returns http success" do
      get 'similarMovies'
      response.should be_success
    end
  end

  describe "GET 'index'" do
    it "returns http success" do
      get 'index'
      response.should be_success
    end
  end

end
